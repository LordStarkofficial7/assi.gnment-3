//#include <iostream>
//using namespace std;
//
//const int STUDENTS = 10;
//const int SUBJECTS = 5;
//void inputMarks(int marks[STUDENTS][SUBJECTS]) 
//{
//    for (int i = 0; i < STUDENTS; ++i) 
//    {
//        cout << "Enter marks for Student " << i + 1 << endl;
//        for (int j = 0; j < SUBJECTS; ++j) 
//        {
//            cout << "  Subject " << j + 1 << ": ";
//            cin >> marks[i][j];
//        }
//    }
//}
//
//void calculateResults(int marks[STUDENTS][SUBJECTS]) 
//{
//    int topScorerIndex = 0;
//    float highestAvg = 0;
//
//    cout << "\nStudent\tTotal\tAverage\tGrade\n";
//
//    for (int i = 0; i < STUDENTS; ++i)
//    {
//        int total = 0;
//        for (int j = 0; j < SUBJECTS; ++j) 
//        {
//            total += marks[i][j];
//        }
//        float average = static_cast<float>(total) / SUBJECTS;
//        char grade;
//        if (average >= 90) grade = 'A';
//        else if (average >= 80) grade = 'B';
//        else if (average >= 70) grade = 'C';
//        else grade = 'F';
//
//        cout << i + 1 << "\t" << total << "\t" << average << "\t" << grade << endl;
//
//        if (average > highestAvg) 
//        {
//            highestAvg = average;
//            topScorerIndex = i;
//        }
//    }
//
//    cout << "\nTop Scorer: Student " << topScorerIndex + 1 << " with Average " << highestAvg << endl;
//}
//
//int main() {
//    int marks[STUDENTS][SUBJECTS];
//
//    inputMarks(marks);
//    calculateResults(marks);
//
//    return 0;
//}