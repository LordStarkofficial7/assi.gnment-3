//#include <iostream>
//using namespace std;
//
//const int CANDIDATES = 4;
//const int STATIONS = 6;
//
//void inputVotes(int votes[CANDIDATES][STATIONS]) {
//    cout << "Enter votes for each candidate at each polling station:\n";
//    for (int c = 0; c < CANDIDATES; c++) {
//        cout << "Candidate " << c + 1 << ":\n";
//        for (int s = 0; s < STATIONS; s++) {
//            cout << "  Station " << s + 1 << ": ";
//            cin >> votes[c][s];
//            while (votes[c][s] < 0) {
//                cout << "    Invalid votes! Enter non-negative integer: ";
//                cin >> votes[c][s];
//            }
//        }
//    }
//}
//
//void totalVotesPerCandidate(const int votes[CANDIDATES][STATIONS], int totalCandidates[CANDIDATES]) {
//    for (int c = 0; c < CANDIDATES; c++) {
//        int sum = 0;
//        for (int s = 0; s < STATIONS; s++) {
//            sum += votes[c][s];
//        }
//        totalCandidates[c] = sum;
//    }
//}
//
//void totalVotesPerStation(const int votes[CANDIDATES][STATIONS], int totalStations[STATIONS]) {
//    for (int s = 0; s < STATIONS; s++) {
//        int sum = 0;
//        for (int c = 0; c < CANDIDATES; c++) {
//            sum += votes[c][s];
//        }
//        totalStations[s] = sum;
//    }
//}
//
//void identifyWinners(const int totalCandidates[CANDIDATES]) {
//    int maxVotes = totalCandidates[0];
//    for (int i = 1; i < CANDIDATES; i++) {
//        if (totalCandidates[i] > maxVotes)
//            maxVotes = totalCandidates[i];
//    }
//
//    cout << "\nWinner(s) with " << maxVotes << " votes:\n";
//    for (int i = 0; i < CANDIDATES; i++) {
//        if (totalCandidates[i] == maxVotes)
//            cout << " Candidate " << i + 1 << endl;
//    }
//}
//
//void detectLowTurnoutStations(const int totalStations[STATIONS], int threshold = 100) {
//    cout << "\nPolling stations with voter turnout less than " << threshold << ":\n";
//    bool found = false;
//    for (int s = 0; s < STATIONS; s++) {
//        if (totalStations[s] < threshold) {
//            cout << " Station " << s + 1 << " with turnout " << totalStations[s] << endl;
//            found = true;
//        }
//    }
//    if (!found) {
//        cout << " No polling station had turnout less than " << threshold << ".\n";
//    }
//}
//
//int main() {
//    int votes[CANDIDATES][STATIONS];
//    int totalCandidates[CANDIDATES];
//    int totalStations[STATIONS];
//
//    inputVotes(votes);
//    totalVotesPerCandidate(votes, totalCandidates);
//    totalVotesPerStation(votes, totalStations);
//
//    cout << "\nTotal votes per candidate:\n";
//    for (int i = 0; i < CANDIDATES; i++) {
//        cout << "Candidate " << i + 1 << ": " << totalCandidates[i] << endl;
//    }
//
//    cout << "\nTotal votes per polling station:\n";
//    for (int i = 0; i < STATIONS; i++) {
//        cout << "Station " << i + 1 << ": " << totalStations[i] << endl;
//    }
//
//    identifyWinners(totalCandidates);
//    detectLowTurnoutStations(totalStations);
//
//    return 0;
//}