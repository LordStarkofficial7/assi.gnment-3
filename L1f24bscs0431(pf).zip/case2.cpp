//#include <iostream>
//using namespace std;
//
//const int DAYS = 7;
//const int ITEMS = 4;
//void inputSales(float sales[DAYS][ITEMS]) 
//{
//    for (int i = 0; i < DAYS; ++i)
//    {
//        cout << "Enter sales for Day " << i + 1 << endl;
//        for (int j = 0; j < ITEMS; ++j)
//        {
//            cout << "  Item " << j + 1 << ": ";
//            cin >> sales[i][j];
//        }
//    }
//}
//void totalSalesPerItem(float sales[DAYS][ITEMS])
//{
//    cout << "\nTotal Sales per Item:\n";
//    for (int j = 0; j < ITEMS; ++j) 
//    {
//        float total = 0;
//        for (int i = 0; i < DAYS; ++i) 
//        {
//            total += sales[i][j];
//        }
//        cout << "Item " << j + 1 << ": " << total << endl;
//    }
//}
//void totalSalesPerDay(float sales[DAYS][ITEMS])
//{
//    cout << "\nTotal Sales per Day:\n";
//    for (int i = 0; i < DAYS; ++i) 
//    {
//        float total = 0;
//        for (int j = 0; j < ITEMS; ++j) 
//        {
//            total += sales[i][j];
//        }
//        cout << "Day " << i + 1 << ": " << total << endl;
//    }
//}
//int dayWithHighestSales(float sales[DAYS][ITEMS]) 
//{
//    int dayIndex = 0;
//    float maxTotal = 0;
//
//    for (int i = 0; i < DAYS; ++i)
//    {
//        float total = 0;
//        for (int j = 0; j < ITEMS; ++j)
//        {
//            total += sales[i][j];
//        }
//        if (total > maxTotal)
//        {
//            maxTotal = total;
//            dayIndex = i;
//        }
//    }
//    return dayIndex;
//}
//int itemWithHighestSales(float sales[DAYS][ITEMS]) 
//{
//    int itemIndex = 0;
//    float maxTotal = 0;
//
//    for (int j = 0; j < ITEMS; ++j)
//    {
//        float total = 0;
//        for (int i = 0; i < DAYS; ++i)
//        {
//            total += sales[i][j];
//        }
//        if (total > maxTotal)
//        {
//            maxTotal = total;
//            itemIndex = j;
//        }
//    }
//    return itemIndex;
//}
//
//int main() 
//{
//    float sales[DAYS][ITEMS];
//
//    inputSales(sales);
//    totalSalesPerItem(sales);
//    totalSalesPerDay(sales);
//
//    int bestDay = dayWithHighestSales(sales);
//    int bestItem = itemWithHighestSales(sales);
//
//    cout << "\nDay with highest total sales: Day " << bestDay + 1 << endl;
//    cout << "Item with highest total sales: Item " << bestItem + 1 << endl;
//
//    return 0;
//}