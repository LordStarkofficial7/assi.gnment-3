//#include <iostream>
//using namespace std;
//
//const int PATIENTS = 5;
//const int DAYS = 7;
//
//void inputStatus(char records[PATIENTS][DAYS])
//{
//    cout << "Enter patient status for each day (S - Stable, C - Critical, R - Recovered):\n";
//    for (int i = 0; i < PATIENTS; i++)
//    {
//        cout << "Patient " << i + 1 << ": ";
//        for (int j = 0; j < DAYS; j++)
//        {
//            cin >> records[i][j];
//             
//            while (records[i][j] != 'S' && records[i][j] != 'C' && records[i][j] != 'R') 
//            {
//                cout << "Invalid input! Enter S, C, or R: ";
//                cin >> records[i][j];
//            }
//        }
//    }
//}
//
//void countStatuses(char records[PATIENTS][DAYS], int& stableCount, int& criticalCount, int& recoveredCount) {
//    stableCount = criticalCount = recoveredCount = 0;
//    for (int i = 0; i < PATIENTS; i++) {
//        for (int j = 0; j < DAYS; j++) {
//            if (records[i][j] == 'S') stableCount++;
//            else if (records[i][j] == 'C') criticalCount++;
//            else if (records[i][j] == 'R') recoveredCount++;
//        }
//    }
//}
//
//void criticalDaysPerPatient(char records[PATIENTS][DAYS], int criticalDays[PATIENTS]) {
//    for (int i = 0; i < PATIENTS; i++) {
//        criticalDays[i] = 0;
//        for (int j = 0; j < DAYS; j++) {
//            if (records[i][j] == 'C')
//                criticalDays[i]++;
//        }
//    }
//}
//
//int main() {
//    char patientRecords[PATIENTS][DAYS];
//    int stableCount, criticalCount, recoveredCount;
//    int criticalDays[PATIENTS];
//
//    inputStatus(patientRecords);
//    countStatuses(patientRecords, stableCount, criticalCount, recoveredCount);
//    criticalDaysPerPatient(patientRecords, criticalDays);
//
//    cout << "\nTotal count over all patients and days:\n";
//    cout << "Stable (S): " << stableCount << endl;
//    cout << "Critical (C): " << criticalCount << endl;
//    cout << "Recovered (R): " << recoveredCount << endl;
//
//    cout << "\nNumber of days each patient remained Critical:\n";
//    for (int i = 0; i < PATIENTS; i++) {
//        cout << "Patient " << i + 1 << ": " << criticalDays[i] << " day(s)" << endl;
//    }
//
//    return 0;
//}