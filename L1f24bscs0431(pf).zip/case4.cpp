//#include <iostream>
//using namespace std;
//
//const int ROWS = 5;
//const int COLS = 5;
//
//void inputTemperatures(float temps[ROWS][COLS]) {
//    cout << "Enter temperature readings for a 5x5 grid:\n";
//    for (int i = 0; i < ROWS; i++) {
//        cout << "Row " << i + 1 << ": ";
//        for (int j = 0; j < COLS; j++) {
//            cin >> temps[i][j];
//        }
//    }
//}
//
//void averagePerRow(float temps[ROWS][COLS], float avg[ROWS]) {
//    for (int i = 0; i < ROWS; i++) {
//        float sum = 0.0;
//        for (int j = 0; j < COLS; j++) {
//            sum += temps[i][j];
//        }
//        avg[i] = sum / COLS;
//    }
//}
//
//void detectExtremeSpots(float temps[ROWS][COLS], float hotThreshold, float coldThreshold) {
//    cout << "\nExtreme hot spots (>" << hotThreshold << " �C):\n";
//    bool foundHot = false;
//    for (int i = 0; i < ROWS; i++) {
//        for (int j = 0; j < COLS; j++) {
//            if (temps[i][j] > hotThreshold) {
//                cout << "Location (" << i + 1 << "," << j + 1 << ") = " << temps[i][j] << " �C\n";
//                foundHot = true;
//            }
//        }
//    }
//    if (!foundHot) cout << "None\n";
//
//    cout << "\nExtreme cold spots (<" << coldThreshold << " �C):\n";
//    bool foundCold = false;
//    for (int i = 0; i < ROWS; i++) {
//        for (int j = 0; j < COLS; j++) {
//            if (temps[i][j] < coldThreshold) {
//                cout << "Location (" << i + 1 << "," << j + 1 << ") = " << temps[i][j] << " �C\n";
//                foundCold = true;
//            }
//        }
//    }
//    if (!foundCold) cout << "None\n";
//}
//
//int main() {
//    float temperatureGrid[ROWS][COLS];
//    float averages[ROWS];
//
//    inputTemperatures(temperatureGrid);
//    averagePerRow(temperatureGrid, averages);
//
//    cout << "\nAverage temperatures per row (zone):\n";
//    for (int i = 0; i < ROWS; i++) {
//        cout << "Row " << i + 1 << ": " << averages[i] << " �C\n";
//    }
//    float hotThreshold = 40.0;
//    float coldThreshold = 0.0;
//
//    detectExtremeSpots(temperatureGrid, hotThreshold, coldThreshold);
//
//    return 0;
//}