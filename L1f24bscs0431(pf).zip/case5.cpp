//#include <iostream>
//using namespace std;
//
//const int TEAMS = 6;
//const int ROUNDS = 4;
//
//void inputScores(int scores[TEAMS][ROUNDS]) {
//    cout << "Enter scores for each team in each round:\n";
//    for (int i = 0; i < TEAMS; i++) {
//        cout << "Team " << i + 1 << ": ";
//        for (int j = 0; j < ROUNDS; j++) {
//            cin >> scores[i][j];
//            while (scores[i][j] < 0) 
//            {
//                cout << "Score can't be negative! Enter again: ";
//                cin >> scores[i][j];
//            }
//        }
//    }
//}
//
//void totalScores(const int scores[TEAMS][ROUNDS], int total[TEAMS]) {
//    for (int i = 0; i < TEAMS; i++) {
//        total[i] = 0;
//        for (int j = 0; j < ROUNDS; j++) {
//            total[i] += scores[i][j];
//        }
//    }
//}
//
//void findWinnerRunnerUp(const int total[TEAMS], int& winner, int& runnerUp) {
//    winner = runnerUp = -1;
//    int max1 = -1, max2 = -1;
//
//    for (int i = 0; i < TEAMS; i++) {
//        if (total[i] > max1) {
//            max2 = max1;
//            runnerUp = winner;
//            max1 = total[i];
//            winner = i;
//        }
//        else if (total[i] > max2 && i != winner) {
//            max2 = total[i];
//            runnerUp = i;
//        }
//    }
//}
//
//void displayLowScorers(const int scores[TEAMS][ROUNDS], int threshold) {
//    cout << "\nTeams that scored " << threshold << " or less in any round:\n";
//    bool found = false;
//    for (int i = 0; i < TEAMS; i++) {
//        for (int j = 0; j < ROUNDS; j++) {
//            if (scores[i][j] <= threshold) {
//                cout << "Team " << i + 1 << " scored " << scores[i][j] << " in round " << j + 1 << endl;
//                found = true;
//                break;
//            }
//        }
//    }
//    if (!found) cout << "None\n";
//}
//
//int main() {
//    int scores[TEAMS][ROUNDS];
//    int total[TEAMS];
//    int winner, runnerUp;
//
//    inputScores(scores);
//    totalScores(scores, total);
//    findWinnerRunnerUp(total, winner, runnerUp);
//
//    cout << "\nTotal Scores:\n";
//    for (int i = 0; i < TEAMS; i++) {
//        cout << "Team " << i + 1 << ": " << total[i] << endl;
//    }
//
//    cout << "\nWinner: Team " << winner + 1 << " with " << total[winner] << " points\n";
//    cout << "Runner-up: Team " << runnerUp + 1 << " with " << total[runnerUp] << " points\n";
//
//    displayLowScorers(scores, 10);
//
//    return 0;
//}