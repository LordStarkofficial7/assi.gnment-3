//#include <iostream>
//using namespace std;
//
//const int ROWS = 6;
//const int COLS = 4;
//
//void initializeSeats(char seats[ROWS][COLS]) {
//    for (int i = 0; i < ROWS; i++)
//        for (int j = 0; j < COLS; j++)
//            seats[i][j] = 'E';  // All seats initially empty
//}
//
//void displaySeats(const char seats[ROWS][COLS]) {
//    cout << "\nSeat Layout (E = Empty, B = Booked):\n   ";
//    for (int c = 0; c < COLS; c++) {
//        cout << " " << char('A' + c);  
//    }
//    cout << "\n";
//
//    for (int i = 0; i < ROWS; i++) {
//        cout << "Row " << i + 1 << ": ";
//        for (int j = 0; j < COLS; j++) {
//            cout << " " << seats[i][j];
//        }
//        cout << "\n";
//    }
//}
//
//bool bookSeat(char seats[ROWS][COLS], int row, char col) {
//   
//    int colIndex = col - 'A';
//    if (row < 1 || row > ROWS || colIndex < 0 || colIndex >= COLS) {
//        cout << "Invalid seat position!\n";
//        return false;
//    }
//    if (seats[row - 1][colIndex] == 'B') {
//        cout << "Seat already booked.\n";
//        return false;
//    }
//    seats[row - 1][colIndex] = 'B';
//    cout << "Seat " << row << col << " successfully booked.\n";
//    return true;
//}
//
//int countAvailableSeats(const char seats[ROWS][COLS]) {
//    int count = 0;
//    for (int i = 0; i < ROWS; i++)
//        for (int j = 0; j < COLS; j++)
//            if (seats[i][j] == 'E')
//                count++;
//    return count;
//}
//
//int main() {
//    char seats[ROWS][COLS];
//    initializeSeats(seats);
//
//    int choice;
//    do {
//        cout << "\nMenu:\n";
//        cout << "1. Display seating chart\n";
//        cout << "2. Book a seat\n";
//        cout << "3. Count available seats\n";
//        cout << "4. Exit\n";
//        cout << "Enter your choice: ";
//        cin >> choice;
//
//        if (choice == 1) {
//            displaySeats(seats);
//        }
//        else if (choice == 2) {
//            int row;
//            char col;
//            cout << "Enter seat to book (row number and column letter, e.g., 3 B): ";
//            cin >> row >> col;
//            col = toupper(col);
//            bookSeat(seats, row, col);
//        }
//        else if (choice == 3) {
//            int available = countAvailableSeats(seats);
//            cout << "Available seats: " << available << endl;
//        }
//        else if (choice == 4) {
//            cout << "Exiting...\n";
//        }
//        else {
//            cout << "Invalid choice! Try again.\n";
//        }
//    } while (choice != 4);
//
//    return 0;
//}