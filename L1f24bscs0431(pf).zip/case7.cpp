//#include <iostream>
//using namespace std;
//
//const int PRODUCTS = 5;
//const int USERS = 10;
//
//void inputRatings(int ratings[PRODUCTS][USERS]) {
//    cout << "Enter ratings (1 to 5) for each product by each user:\n";
//    for (int i = 0; i < PRODUCTS; i++) {
//        cout << "Product " << i + 1 << ":\n";
//        for (int j = 0; j < USERS; j++) {
//            cout << " User " << j + 1 << ": ";
//            cin >> ratings[i][j];
//            while (ratings[i][j] < 1 || ratings[i][j] > 5) {
//                cout << "  Invalid rating! Enter rating (1 to 5): ";
//                cin >> ratings[i][j];
//            }
//        }
//    }
//}
//
//void averageRatings(const int ratings[PRODUCTS][USERS], float avg[PRODUCTS]) {
//    for (int i = 0; i < PRODUCTS; i++) {
//        int sum = 0;
//        for (int j = 0; j < USERS; j++) {
//            sum += ratings[i][j];
//        }
//        avg[i] = static_cast<float>(sum) / USERS;
//    }
//}
//
//void countPerfectRatings(const int ratings[PRODUCTS][USERS], int perfectCount[PRODUCTS]) {
//    for (int i = 0; i < PRODUCTS; i++) {
//        perfectCount[i] = 0;
//        for (int j = 0; j < USERS; j++) {
//            if (ratings[i][j] == 5)
//                perfectCount[i]++;
//        }
//    }
//}
//
//void displayWorstProducts(const float avg[PRODUCTS]) {
//    float worstAvg = avg[0];
//    for (int i = 1; i < PRODUCTS; i++) {
//        if (avg[i] < worstAvg)
//            worstAvg = avg[i];
//    }
//
//    cout << "\nProduct(s) with the worst average rating (" << worstAvg << "):\n";
//    for (int i = 0; i < PRODUCTS; i++) {
//        if (avg[i] == worstAvg)
//            cout << " Product " << i + 1 << endl;
//    }
//}
//
//int main() {
//    int ratings[PRODUCTS][USERS];
//    float avg[PRODUCTS];
//    int perfectCount[PRODUCTS];
//
//    inputRatings(ratings);
//    averageRatings(ratings, avg);
//    countPerfectRatings(ratings, perfectCount);
//
//    cout << "\nAverage Ratings per Product:\n";
//    for (int i = 0; i < PRODUCTS; i++) {
//        cout << "Product " << i + 1 << ": " << avg[i] << endl;
//    }
//
//    cout << "\nCount of Perfect (5) Ratings per Product:\n";
//    for (int i = 0; i < PRODUCTS; i++) {
//        cout << "Product " << i + 1 << ": " << perfectCount[i] << endl;
//    }
//
//    displayWorstProducts(avg);
//
//    return 0;
//}