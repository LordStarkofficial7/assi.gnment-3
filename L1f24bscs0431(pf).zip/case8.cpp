//#include <iostream>
//using namespace std;
//
//const int ROWS = 5;
//const int COLS = 5;
//
//void inputBookStatus(char books[ROWS][COLS]) {
//    cout << "Enter book status for each shelf and position (A/I/M):\n";
//    for (int i = 0; i < ROWS; i++) {
//        cout << "Shelf " << i + 1 << ": ";
//        for (int j = 0; j < COLS; j++) {
//            cin >> books[i][j];
//            
//            while (books[i][j] != 'A' && books[i][j] != 'I' && books[i][j] != 'M' &&
//                books[i][j] != 'a' && books[i][j] != 'i' && books[i][j] != 'm') {
//                cout << "Invalid status! Enter A, I or M: ";
//                cin >> books[i][j];
//            }
//            
//            if (books[i][j] >= 'a' && books[i][j] <= 'z') {
//                books[i][j] = books[i][j] - 'a' + 'A';
//            }
//        }
//    }
//}
//
//void displayBookStatus(const char books[ROWS][COLS]) {
//    cout << "\nLibrary Book Status:\n   ";
//    for (int c = 0; c < COLS; c++) cout << " " << c + 1;
//    cout << "\n";
//
//    for (int i = 0; i < ROWS; i++) {
//        cout << "Shelf " << i + 1 << ": ";
//        for (int j = 0; j < COLS; j++) {
//            cout << " " << books[i][j];
//        }
//        cout << "\n";
//    }
//}
//
//void countStatus(const char books[ROWS][COLS], int& available, int& issued, int& missing) {
//    available = issued = missing = 0;
//    for (int i = 0; i < ROWS; i++) {
//        for (int j = 0; j < COLS; j++) {
//            switch (books[i][j]) {
//            case 'A': available++; break;
//            case 'I': issued++; break;
//            case 'M': missing++; break;
//            }
//        }
//    }
//}
//
//void identifyRowsHighestMissing(const char books[ROWS][COLS]) {
//    int maxMissing = 0;
//    int missingCount[ROWS] = { 0 };
//
//    for (int i = 0; i < ROWS; i++) {
//        int count = 0;
//        for (int j = 0; j < COLS; j++) {
//            if (books[i][j] == 'M') count++;
//        }
//        missingCount[i] = count;
//        if (count > maxMissing) maxMissing = count;
//    }
//
//    cout << "\nShelf(es) with the highest missing books (" << maxMissing << " missing):\n";
//    for (int i = 0; i < ROWS; i++) {
//        if (missingCount[i] == maxMissing)
//            cout << " Shelf " << i + 1 << endl;
//    }
//}
//
//int main() {
//    char books[ROWS][COLS];
//    int available, issued, missing;
//
//    inputBookStatus(books);
//    displayBookStatus(books);
//
//    countStatus(books, available, issued, missing);
//
//    cout << "\nTotal Available Books: " << available << endl;
//    cout << "Total Issued Books: " << issued << endl;
//    cout << "Total Missing Books: " << missing << endl;
//
//    identifyRowsHighestMissing(books);
//
//    return 0;
//}