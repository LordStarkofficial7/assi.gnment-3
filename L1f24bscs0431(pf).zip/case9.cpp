//#include <iostream>
//using namespace std;
//
//const int SHIFTS = 3;
//const int DAYS = 7;
//
//void inputDefects(float defects[SHIFTS][DAYS]) {
//    cout << "Enter defect percentages for each shift (1-3) and day (1-7):\n";
//    for (int i = 0; i < SHIFTS; i++) {
//        for (int j = 0; j < DAYS; j++) {
//            cout << "Shift " << i + 1 << ", Day " << j + 1 << ": ";
//            cin >> defects[i][j];
//            while (defects[i][j] < 0 || defects[i][j] > 100) {
//                cout << "Invalid percentage! Enter value between 0 and 100: ";
//                cin >> defects[i][j];
//            }
//        }
//    }
//}
//
//void averagePerShift(const float defects[SHIFTS][DAYS], float avgShift[SHIFTS]) {
//    for (int i = 0; i < SHIFTS; i++) {
//        float sum = 0;
//        for (int j = 0; j < DAYS; j++) {
//            sum += defects[i][j];
//        }
//        avgShift[i] = sum / DAYS;
//    }
//}
//
//void averagePerDay(const float defects[SHIFTS][DAYS], float avgDay[DAYS]) {
//    for (int j = 0; j < DAYS; j++) {
//        float sum = 0;
//        for (int i = 0; i < SHIFTS; i++) {
//            sum += defects[i][j];
//        }
//        avgDay[j] = sum / SHIFTS;
//    }
//}
//
//void identifyCriticalShifts(const float avgShift[SHIFTS], float threshold = 10.0) {
//    cout << "\nCritical shifts (avg defects > " << threshold << "%):\n";
//    bool found = false;
//    for (int i = 0; i < SHIFTS; i++) {
//        if (avgShift[i] > threshold) {
//            cout << " Shift " << i + 1 << " with average defect " << avgShift[i] << "%\n";
//            found = true;
//        }
//    }
//    if (!found) {
//        cout << "No critical shifts found.\n";
//    }
//}
//
//int main() {
//    float defects[SHIFTS][DAYS];
//    float avgShift[SHIFTS], avgDay[DAYS];
//
//    inputDefects(defects);
//    averagePerShift(defects, avgShift);
//    averagePerDay(defects, avgDay);
//
//    cout << "\nAverage defect percentage per shift:\n";
//    for (int i = 0; i < SHIFTS; i++) {
//        cout << " Shift " << i + 1 << ": " << avgShift[i] << "%\n";
//    }
//
//    cout << "\nAverage defect percentage per day:\n";
//    for (int j = 0; j < DAYS; j++) {
//        cout << " Day " << j + 1 << ": " << avgDay[j] << "%\n";
//    }
//
//    identifyCriticalShifts(avgShift);
//
//    return 0;
//}